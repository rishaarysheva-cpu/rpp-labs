import asyncio
import time
from contextlib import asynccontextmanager
from datetime import date
import httpx
from fastapi import FastAPI, HTTPException, Request
from sqlalchemy.ext.asyncio import create_async_engine
from database import DATABASE_URL, day_query
from sync_service import PROVIDERS
from routes import build_routes


@asynccontextmanager
async def lifespan(app):
    app.state.engine = create_async_engine(
        DATABASE_URL.replace('postgresql+psycopg://', 'postgresql+asyncpg://'))
    app.state.client = httpx.AsyncClient(
        trust_env=False,
        limits=httpx.Limits(max_connections=300, max_keepalive_connections=100))
    yield
    await app.state.client.aclose()
    await app.state.engine.dispose()


app = FastAPI(lifespan=lifespan)


async def fetch_provider(client, url, day):
    try:
        async with asyncio.timeout(2):
            for attempt in range(2):
                try:
                    response = await client.get(url + '/flights',
                        params={'date': day.isoformat()}, timeout=None)
                    response.raise_for_status()
                    return response.json()
                except httpx.HTTPError:
                    if attempt == 1:
                        return None
                    await asyncio.sleep(0.2)
    except TimeoutError:
        return None


async def load_flights(engine, day):
    async with engine.connect() as connection:
        result = await connection.execute(day_query(day))
        return [dict(row) for row in result.mappings()]


@app.get('/search')
async def search(origin: str, destination: str, date: date, request: Request):
    started = time.perf_counter()
    state = request.app.state
    own, *results = await asyncio.gather(
        load_flights(state.engine, date),
        *(fetch_provider(state.client, url, date) for url in PROVIDERS))
    failed = []
    for number, result in enumerate(results, 1):
        if result is None:
            failed.append(f'P{number}')
        else:
            own.extend(result)
    if not own and len(failed) == len(PROVIDERS):
        raise HTTPException(503, 'Поиск временно недоступен')
    return {'routes': build_routes(own, origin, destination, date),
            'failed_providers': failed,
            'elapsed_ms': round((time.perf_counter() - started) * 1000, 2)}


@app.get('/health')
async def health():
    return {'status': 'ok'}
