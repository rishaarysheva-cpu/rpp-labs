import os
import time
from contextlib import asynccontextmanager
from datetime import date
import requests
from fastapi import FastAPI, HTTPException, Request
from database import DATABASE_URL, create_engine, load_flights
from routes import build_routes

PROVIDERS = os.getenv('PROVIDERS',
    'http://provider1:8000,http://provider2:8000,http://provider3:8000').split(',')


@asynccontextmanager
async def lifespan(app):
    app.state.engine = create_engine(DATABASE_URL)
    yield
    app.state.engine.dispose()


app = FastAPI(lifespan=lifespan)


def fetch_provider(url, day):
    deadline = time.monotonic() + 2
    for attempt in range(2):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None
        try:
            response = requests.get(url + '/flights', params={'date': day.isoformat()},
                                    timeout=remaining)
            response.raise_for_status()
            result = response.json()
            return result if time.monotonic() <= deadline else None
        except requests.Timeout:
            return None
        except requests.RequestException:
            if attempt == 1 or deadline - time.monotonic() <= 0.2:
                return None
            time.sleep(0.2)
    return None


@app.get('/search')
def search(origin: str, destination: str, date: date, request: Request):
    started = time.perf_counter()
    flights = load_flights(request.app.state.engine, date)
    failed = []
    for number, url in enumerate(PROVIDERS, 1):
        result = fetch_provider(url, date)
        if result is None:
            failed.append(f'P{number}')
        else:
            flights.extend(result)
    if not flights and len(failed) == len(PROVIDERS):
        raise HTTPException(503, 'Поиск временно недоступен')
    return {'routes': build_routes(flights, origin, destination, date),
            'failed_providers': failed,
            'elapsed_ms': round((time.perf_counter() - started) * 1000, 2)}


@app.get('/health')
def health():
    return {'status': 'ok'}
