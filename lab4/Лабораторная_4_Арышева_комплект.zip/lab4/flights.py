import random
from datetime import date, datetime, time, timedelta

AIRPORTS = ['OVB', 'SVO', 'DME', 'VKO', 'LED', 'SVX', 'KZN', 'UFA',
            'KRR', 'AER', 'ROV', 'KUF', 'OMS', 'TOF', 'KEJ', 'KJA',
            'IKT', 'UUD', 'HTA', 'YKS', 'VVO', 'KHV', 'PKC', 'GDX',
            'UUS', 'KGD', 'MMK', 'ARH', 'PEE', 'CEK']
START_DATE = date(2026, 11, 1)


def generate_flights(day: date, carrier: str, count: int) -> list[dict]:
    rng = random.Random(f'{carrier}:{day.isoformat()}')
    midnight = datetime.combine(day, time())
    flights = []
    for number in range(1, count + 1):
        origin, destination = rng.sample(AIRPORTS, 2)
        departure = midnight + timedelta(minutes=rng.randrange(1440))
        arrival = departure + timedelta(minutes=rng.randint(60, 360))
        flights.append(dict(carrier=carrier, flight_number=f'{carrier}-{number:04}',
                            origin=origin, destination=destination,
                            departure_time=departure.isoformat(),
                            arrival_time=arrival.isoformat(),
                            price=rng.randint(2000, 30000)))
    return flights
