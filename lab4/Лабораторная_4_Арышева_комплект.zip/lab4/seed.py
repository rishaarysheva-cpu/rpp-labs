from datetime import datetime, timedelta
from sqlalchemy.dialects.postgresql import insert
from database import DATABASE_URL, metadata, flights, create_engine
from flights import START_DATE, generate_flights

if __name__ == '__main__':
    engine = create_engine(DATABASE_URL)
    metadata.create_all(engine)
    with engine.begin() as connection:
        for offset in range(120):
            rows = generate_flights(START_DATE + timedelta(days=offset), 'OWN', 1500)
            for row in rows:
                for field in ('departure_time', 'arrival_time'):
                    row[field] = datetime.fromisoformat(row[field])
            connection.execute(insert(flights).on_conflict_do_nothing(), rows)
    engine.dispose()
    print('Загружено расписание: 120 дней по 1500 рейсов, всего 180000.')
