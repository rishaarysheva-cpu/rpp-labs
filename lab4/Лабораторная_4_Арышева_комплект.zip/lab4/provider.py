import asyncio
import os
import random
from datetime import date
from fastapi import FastAPI, HTTPException
from flights import generate_flights

PROVIDER_ID = os.getenv('PROVIDER_ID', 'P1')
DELAY_MS = float(os.getenv('DELAY_MS', '300'))
JITTER = float(os.getenv('JITTER', '0.30'))
ERROR_RATE = float(os.getenv('ERROR_RATE', '0.05'))
SLOW_RATE = float(os.getenv('SLOW_RATE', '0'))
FLIGHTS_PER_DAY = int(os.getenv('FLIGHTS_PER_DAY', '500'))
app = FastAPI()


@app.get('/flights')
async def get_flights(date: date):
    delay = 3 if random.random() < SLOW_RATE else (
        DELAY_MS / 1000 * random.uniform(1 - JITTER, 1 + JITTER))
    await asyncio.sleep(delay)
    if random.random() < ERROR_RATE:
        raise HTTPException(500, 'Ошибка поставщика')
    return generate_flights(date, PROVIDER_ID, FLIGHTS_PER_DAY)


@app.get('/health')
async def health():
    return {'status': 'ok'}
