from bisect import bisect_left, bisect_right
from datetime import datetime, timedelta
from heapq import heappush, heapreplace


def build_routes(flights, origin, destination, day):
    by_origin = {}
    for source in flights:
        flight = dict(source)
        for field in ('departure_time', 'arrival_time'):
            if isinstance(flight[field], str):
                flight[field] = datetime.fromisoformat(flight[field])
        if flight['departure_time'].date() == day:
            by_origin.setdefault(flight['origin'], []).append(flight)
    departures = {}
    for airport, outgoing in by_origin.items():
        outgoing.sort(key=lambda flight: flight['departure_time'])
        departures[airport] = [flight['departure_time'] for flight in outgoing]
    best = []
    serial = 0

    def walk(airport, path, visited, price):
        nonlocal serial
        outgoing = by_origin.get(airport, [])
        left, right = 0, len(outgoing)
        if path:
            arrival = path[-1]['arrival_time']
            times = departures.get(airport, [])
            left = bisect_left(times, arrival + timedelta(hours=1))
            right = bisect_right(times, arrival + timedelta(hours=6))
        for flight in outgoing[left:right]:
            target = flight['destination']
            total = price + flight['price']
            if target in visited or (len(best) == 20 and total >= -best[0][0]):
                continue
            next_path = path + [flight]
            if target == destination:
                serial += 1
                item = (-total, serial, next_path)
                if len(best) < 20:
                    heappush(best, item)
                else:
                    heapreplace(best, item)
            elif len(next_path) < 3:
                walk(target, next_path, visited | {target}, total)

    walk(origin, [], {origin}, 0)
    return [{'price': -cost, 'flights': path}
            for cost, _, path in sorted(best, key=lambda item: (-item[0], item[1]))]
