#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p results
docker compose build
docker compose up -d --wait db provider1 provider2 provider3
for module in sync_service blocking_service async_service; do
  for clients in 1 10 40 80; do
    APP_MODULE="$module" docker compose up -d --no-deps --force-recreate --wait search
    docker compose run --rm --no-deps search python load_test.py \
      --url http://search:8000 --mode closed --clients "$clients" \
      --warmup 10 --duration 60 --output "/results/${module}_C${clients}.json"
  done
  APP_MODULE="$module" docker compose up -d --no-deps --force-recreate --wait search
  docker compose run --rm --no-deps search python load_test.py \
    --url http://search:8000 --mode open --rate 5 --warmup 10 --duration 60 \
    --output "/results/${module}_open5.json"
done
# Профилирование отдельно от таблицы замеров, чтобы не влиять на неё.
APP_MODULE=sync_service docker compose up -d --no-deps --force-recreate --wait search
for variant in active idle; do
  docker compose run --rm --no-deps search python load_test.py \
    --url http://search:8000 --clients 10 --warmup 10 --duration 70 \
    > "results/profile_load_${variant}.json" &
  load_pid=$!
  sleep 10
  if [ "$variant" = idle ]; then
    docker compose exec -T search py-spy record --pid 1 --duration 60 \
      --idle -o /results/sync_idle.svg
  else
    docker compose exec -T search py-spy record --pid 1 --duration 60 \
      -o /results/sync_active.svg
  fi
  wait "$load_pid"
done
APP_MODULE=blocking_service docker compose up -d --no-deps --force-recreate --wait search
docker compose run --rm --no-deps search python load_test.py \
  --url http://search:8000 --clients 10 --warmup 10 --duration 60 \
  > results/dump_load.json &
load_pid=$!
sleep 15
docker compose exec -T search py-spy dump --pid 1 > results/blocking_dump.txt
wait "$load_pid"
docker compose stop search
printf '%s\n' 'Замеры и профили сохранены в каталоге results.'
