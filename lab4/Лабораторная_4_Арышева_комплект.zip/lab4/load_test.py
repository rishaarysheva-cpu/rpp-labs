import argparse
import asyncio
import json
import math
import random
import time
from pathlib import Path
import httpx


def summarize(rows, duration, end):
    values = sorted(milliseconds for milliseconds, error, finished in rows)
    def percentile(q):
        return round(values[max(0, math.ceil(len(values) * q) - 1)], 2) if values else None
    return {'count': len(rows), 'rps': round(sum(finished <= end for _, _, finished in rows) / duration, 3),
            'p50_ms': percentile(.50), 'p95_ms': percentile(.95),
            'p99_ms': percentile(.99), 'max_ms': round(max(values), 2) if values else None,
            'errors_percent': round(100 * sum(error for _, error, _ in rows) / len(rows), 2)
                              if rows else None}


async def run(args):
    rows = {'search': [], 'health': []}
    params = {'origin': args.origin, 'destination': args.destination, 'date': args.date}
    limits = httpx.Limits(max_connections=None, max_keepalive_connections=200)
    async with httpx.AsyncClient(base_url=args.url, timeout=30, limits=limits, trust_env=False) as client:
        async def request(kind, record):
            start = time.perf_counter()
            try:
                response = await client.get('/' + kind, params=params if kind == 'search' else None)
                error = response.status_code >= 400
            except httpx.HTTPError:
                error = True
            if record and measurement_start <= start < measurement_end:
                finished = time.perf_counter()
                rows[kind].append(((finished - start) * 1000, error, finished))

        async def phase(duration, record):
            end = time.perf_counter() + duration
            async def worker():
                while time.perf_counter() < end:
                    await request('search', record)
            async def open_load():
                pending = []
                due = time.perf_counter()
                while True:
                    due += random.expovariate(args.rate)
                    if due >= end:
                        break
                    await asyncio.sleep(max(0, due - time.perf_counter()))
                    pending.append(asyncio.create_task(request('search', record)))
                await asyncio.gather(*pending)
            async def health_load():
                pending = []
                due = time.perf_counter()
                while due < end:
                    await asyncio.sleep(max(0, due - time.perf_counter()))
                    pending.append(asyncio.create_task(request('health', record)))
                    due += .1
                await asyncio.gather(*pending)
            search = open_load() if args.mode == 'open' else asyncio.gather(
                *(worker() for _ in range(args.clients)))
            await asyncio.gather(search, health_load())

        measurement_start = time.perf_counter() + args.warmup
        measurement_end = measurement_start + args.duration
        await phase(args.warmup + args.duration, True)
    result = {'mode': args.mode, 'clients': args.clients if args.mode == 'closed' else None,
              'rate': args.rate if args.mode == 'open' else None,
              'duration_s': args.duration, 'warmup_s': args.warmup,
              'search': summarize(rows['search'], args.duration, measurement_end),
              'health': summarize(rows['health'], args.duration, measurement_end)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if args.output:
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', default='http://localhost:8000')
    parser.add_argument('--mode', choices=['closed', 'open'], default='closed')
    parser.add_argument('--clients', type=int, default=1)
    parser.add_argument('--rate', type=float, default=5)
    parser.add_argument('--duration', type=float, default=60)
    parser.add_argument('--warmup', type=float, default=10)
    parser.add_argument('--date', default='2026-11-08')
    parser.add_argument('--origin', default='OVB')
    parser.add_argument('--destination', default='SVO')
    parser.add_argument('--output')
    asyncio.run(run(parser.parse_args()))
