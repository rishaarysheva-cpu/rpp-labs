import os
from datetime import date, datetime, time, timedelta
from sqlalchemy import (MetaData, Table, Column, String, DateTime, Integer,
                        Index, select, create_engine)

DATABASE_URL = os.getenv('DATABASE_URL',
                         'postgresql+psycopg://lab:lab@db:5432/flights')
metadata = MetaData()
flights = Table('flights', metadata,
    Column('carrier', String, nullable=False),
    Column('flight_number', String, primary_key=True),
    Column('origin', String(3), nullable=False),
    Column('destination', String(3), nullable=False),
    Column('departure_time', DateTime, primary_key=True),
    Column('arrival_time', DateTime, nullable=False),
    Column('price', Integer, nullable=False))
Index('ix_flights_departure_time', flights.c.departure_time)


def day_query(day: date):
    start = datetime.combine(day, time())
    return select(flights).where(flights.c.departure_time >= start,
                                flights.c.departure_time < start + timedelta(days=1))


def load_flights(engine, day: date):
    with engine.connect() as connection:
        return [dict(row) for row in connection.execute(day_query(day)).mappings()]
